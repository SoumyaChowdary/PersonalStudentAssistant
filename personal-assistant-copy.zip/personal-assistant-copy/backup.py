import os
import streamlit as st
from langchain.chains import ConversationalRetrievalChain
from langchain.document_loaders import DirectoryLoader, WebBaseLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.chat_models import ChatOpenAI
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import FAISS
import constants

# def clear_input():
#     # This function will clear the input box after the submit button is pressed
#     st.session_state.user_query = ""

def set_api_key():
    if hasattr(constants, 'APIKEY') and constants.APIKEY:
        os.environ["OPENAI_API_KEY"] = constants.APIKEY
    else:
        st.error("OPENAI_API_KEY is not set. Please configure it in constants.py.")

def initialize_system(data_src_option, subfolder_option=None, src_url=None):
    if data_src_option == 'From Local Storage' and subfolder_option and subfolder_option != 'Select an option':
        folder_paths = {
            'Personal Documents': 'Personal/',
            'Course Content': 'Subject/',
            'Research Papers': 'Research/'
        }
        selected_folder_path = folder_paths[subfolder_option]
        # loader = DirectoryLoader(selected_folder_path, show_progress=True, use_multithreading=True)
        loader = DirectoryLoader('data/', show_progress=True, use_multithreading=True)
    elif data_src_option == 'From Web' and src_url:
        loader = WebBaseLoader([src_url])
    else:
        return None

    loaded_docs = loader.load()
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=3000,
        chunk_overlap=600,
        length_function=len,
        add_start_index=True,
        is_separator_regex=False,
    )
    all_splits = text_splitter.split_documents(loaded_docs)
    embeddings_model = OpenAIEmbeddings()
    faiss_index_path = f"faiss_{subfolder_option.lower().replace(' ', '_')}_index" if subfolder_option else "faiss_web_index"
    
    if os.path.exists(faiss_index_path):
        if(faiss_index_path=="faiss_web_index"):
            db = FAISS.from_documents(all_splits, embeddings_model)
            db.save_local(faiss_index_path)
        else:
            db = FAISS.load_local(faiss_index_path, embeddings_model)
    else:
        db = FAISS.from_documents(all_splits, embeddings_model)
        db.save_local(faiss_index_path)
    
    chain = ConversationalRetrievalChain.from_llm(
        llm=ChatOpenAI(model="gpt-3.5-turbo-16k"),
        retriever=db.as_retriever(search_kwargs={"k": 1}),
    )

    return chain

def main():
    st.title("Personal Assistant")
    set_api_key()

    data_src_option = st.radio(
        "Specify the data source:",
        ('Select an option', 'From Local Storage', 'From Web'),
        index=0
    )

    chain = None
    if data_src_option == 'From Local Storage':
        subfolder_option = st.radio(
            "Select the category:",
            ('Select an option', 'Personal Documents', 'Course Content', 'Research Papers'),
            index=0
        )
        if subfolder_option != 'Select an option':
            if f'chain_{subfolder_option}' not in st.session_state:
                st.session_state[f'chain_{subfolder_option}'] = initialize_system(data_src_option, subfolder_option=subfolder_option)
            chain = st.session_state[f'chain_{subfolder_option}']
    elif data_src_option == 'From Web':
        src_url = st.text_input("Enter the Source URL to query on:")
        if src_url:
            if 'chain_web' not in st.session_state:
                st.session_state['chain_web'] = initialize_system(data_src_option, src_url=src_url)
            chain = st.session_state['chain_web']

    # Ensure chat history is initialized in session state
    if 'chat_history' not in st.session_state:
        st.session_state.chat_history = []

    if chain:
        user_query = st.text_input("Enter your query here:", key="user_query")
        if st.button('Submit') and user_query:
            # Include chat_history in the input to chain
            
            result = chain({"question": user_query, "chat_history": st.session_state.chat_history})
            st.write(result['answer'])
            st.session_state.chat_history.append((user_query, result['answer']))
            # new_chat_history = [(user_query, result['answer'])] + st.session_state.chat_history
            # st.session_state.chat_history = new_chat_history
            

    else:
        st.write("Please select a data source and configure it to proceed.")
                
    st.write("Chat History:")
    
    for i, (query, response) in enumerate(reversed(st.session_state.chat_history), start=1):
        # Create a hash of the query and response as a unique identifier
        query_hash = hash(query) % (10 ** 8)  # Take modulo to limit the length of the hash
        response_hash = hash(response) % (10 ** 8)  # Take modulo to limit the length of the hash
        curr_i = len(st.session_state.chat_history) - i + 1  # Calculate the current index in the chat history
        # Use the unique identifier in the key for the text areas
        st.text_area(f"Q{curr_i}:", value=query, height=75, key=f"q{i}_{query_hash}")
        st.text_area(f"A{curr_i}:", value=response, height=75, key=f"a{i}_{response_hash}")

if __name__ == "__main__":
    main()
