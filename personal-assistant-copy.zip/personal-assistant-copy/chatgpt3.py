import os
import sys

from langchain.chains import ConversationalRetrievalChain
from langchain.document_loaders import DirectoryLoader,TextLoader,WebBaseLoader

from langchain.text_splitter import RecursiveCharacterTextSplitter

from langchain.chat_models import ChatOpenAI
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import Chroma


import constants

os.environ["OPENAI_API_KEY"] = constants.APIKEY

print("Specify the data source: ")
data_src = int(input("1)From Local Storage    2)From Web: "))

loader = None

if data_src == 1:
  loader = DirectoryLoader("data/",show_progress=True, use_multithreading=True)
else:
  src_url = input("Enter the Source URL to query on:")
  loader = WebBaseLoader([src_url])



loaded_docs = loader.load()


embeddings_model = OpenAIEmbeddings()
db = Chroma.from_documents(loaded_docs, OpenAIEmbeddings())


query = None
if len(sys.argv) > 1:
  query = sys.argv[1]

chain = ConversationalRetrievalChain.from_llm(
  llm=ChatOpenAI(model="gpt-3.5-turbo-16k"),
  retriever=db.as_retriever(search_kwargs={"k": 1}),
)



chat_history = []
while True:
  if not query:
    query = input("Prompt: ")
  if query in ['quit', 'q', 'exit']:
    sys.exit()
  result = chain({"question": query, "chat_history": chat_history})
  print(result['answer'])
#   print(result)

  chat_history.append((query, result['answer']))
  query = None


# embeddings_model = OpenAIEmbeddings()

# # doc_contents = [x.page_content for x in loaded_docs]
# # embeddings = embeddings_model.embed_documents(doc_contents)
# # embedded_query = embeddings_model.embed_query("What is my cat's name?")
# # print(embedded_query[:6])

# db = Chroma.from_documents(loaded_docs, OpenAIEmbeddings())

# query = "What is my cat's name?"
# docs = db.similarity_search(query)
# print(docs[0].page_content)