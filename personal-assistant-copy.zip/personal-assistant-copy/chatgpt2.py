import os
import sys
import streamlit as st
from langchain.chains import ConversationalRetrievalChain
from langchain.document_loaders import DirectoryLoader,TextLoader,WebBaseLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter, CharacterTextSplitter
from langchain.chat_models import ChatOpenAI
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import Chroma
from langchain.vectorstores import FAISS
import constants

def set_api_key():
  if constants.APIKEY:
    os.environ["OPENAI_API_KEY"] = constants.APIKEY
  else:
    raise ValueError("OPENAI_API_KEY is not set.")

def main():
  st.title("Personal Assistant")
  st.write("Ask me anything!")

  set_api_key()
  
  # Radio button for data source selection
  data_src_option = st.radio(
    "Specify the data source:",
    ('Select an option', 'From Local Storage', 'From Web'),
    index=0  # Default to the first option which prompts user to select
  )

  # Initialize variable to hold loaded documents
  loaded_docs = None

  # Handle local storage selection
  if data_src_option == 'From Local Storage':
        # Assuming files are in 'data/' and you want to use DirectoryLoader
        st.write("Loading documents from the local 'data/' directory.")
        loader = DirectoryLoader("data/", show_progress=True, use_multithreading=True)
        loaded_docs = loader.load()
        # Optionally, display a success message or the number of documents loaded
        if loaded_docs:
            st.success(f"Loaded documents from local storage successfully.")

  # Handle web source selection
  elif data_src_option == 'From Web':
    src_url = st.text_input("Enter the Source URL to query on:")
    if src_url:
      # Use WebBaseLoader for loading documents from the provided URL
      loader = WebBaseLoader([src_url])
      loaded_docs = loader.load()
      # Display a success message or the number of documents loaded
      if loaded_docs:
        st.success(f"Loaded documents from {src_url} successfully.")
      else:
        st.error("Failed to load documents from the URL.")

  text_splitter = RecursiveCharacterTextSplitter(
    chunk_size = 3000,
    chunk_overlap  = 600,
    length_function = len,
    add_start_index=True,
    is_separator_regex = False,
  )

  db = None
  chain = None
  if loaded_docs is not None:
    with st.spinner("Processing documents..."):
      all_splits = text_splitter.split_documents(loaded_docs)

    embeddings_model = OpenAIEmbeddings()

    faiss_index_path = "faiss_index2"
    if data_src_option == "From Local Storage":
      faiss_index_path = "faiss_index1"

    # Replace print statements with st.write or st.success
    if os.path.exists(faiss_index_path):
      st.success("Loading from local storage.")
      db = FAISS.load_local(faiss_index_path, embeddings_model)
    else:
        with st.spinner("Creating database..."):
          db = FAISS.from_documents(all_splits, embeddings_model)
          db.save_local(faiss_index_path)
        st.success("Database created successfully.")
    
    # Check if `db` is successfully created/loaded before initializing `chain`
    if db is not None:
      chain = ConversationalRetrievalChain.from_llm(
        llm=ChatOpenAI(model="gpt-3.5-turbo-16k"),
        retriever=db.as_retriever(search_kwargs={"k": 1}),
      )
    else:
      st.error("Failed to initialize the database.")


  if 'chat_history' not in st.session_state:
    st.session_state.chat_history = []

  # Text input for user query
  user_query = st.text_input("Enter your query here:")

  # Button to submit the query
  submit_button = st.button('Submit')

  # Ensure `chain` is initialized before processing queries
  if submit_button and user_query and chain is not None:
    result = chain({"question": user_query, "chat_history": st.session_state.chat_history})
    st.write(result['answer'])
    st.session_state.chat_history.append((user_query, result['answer']))
  elif submit_button and user_query and chain is None:
    st.error("The retrieval system is not initialized. Please ensure a data source is selected and documents are loaded.")

  st.write("Chat History:")
  for i, (query, response) in enumerate(st.session_state.chat_history, start=1):
    st.text_area(f"Q{i}:", value=query, height=75, key=f"q{i}")
    st.text_area(f"A{i}:", value=response, height=75, key=f"a{i}")

if __name__ == "__main__":
    main()