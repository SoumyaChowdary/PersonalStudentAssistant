# Replace with your own OpenAI API Key https://platform.openai.com/account/api-keys
# and rename this file to constants.py.
#APIKEY = "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"

#GPT Plus
#APIKEY = "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"

#Sweety Sweety 
APIKEY = "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"